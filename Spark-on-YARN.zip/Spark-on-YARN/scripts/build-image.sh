cd config
# Build the images from compose file
docker compose build