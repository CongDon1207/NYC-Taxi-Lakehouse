#!/bin/bash
# Script để liệt kê các Kafka topics
kafka-topics --list --bootstrap-server localhost:9092
