from __future__ import annotations

import pendulum
import os

from airflow import DAG
from airflow.providers.docker.operators.docker import DockerOperator
from docker.types import Mount

# --- Cấu hình chung ---
SPARK_SCRIPTS_DIR = "/opt/airflow/spark-scripts"
SPARK_MASTER = "yarn"
SPARK_DEPLOY_MODE = "client"
SPARK_PACKAGES = (
    "org.apache.spark:spark-sql-kafka-0-10_2.13:3.4.4,"
    "io.delta:delta-core_2.13:2.4.0,"
    "org.apache.hadoop:hadoop-aws:3.3.4,"
    "org.apache.hadoop:hadoop-client-runtime:3.3.4,"
    "org.apache.hadoop:hadoop-client-api:3.3.4,"
    "software.amazon.awssdk:bundle:2.26.19"
)

MINIO_ENDPOINT = "http://minio1:9000"
MINIO_ACCESS_KEY = "minio"
MINIO_SECRET_KEY = "mypassword"
HIVE_METASTORE_URIS = "thrift://hive-service:9083"

SPARK_SUBMIT_CMD = (
    "spark-submit "
    f"--master {SPARK_MASTER} "
    f"--deploy-mode {SPARK_DEPLOY_MODE} "
    f"--packages {SPARK_PACKAGES} "
    "--conf spark.sql.extensions=io.delta.sql.DeltaSparkSessionExtension "
    "--conf spark.sql.catalog.spark_catalog=io.delta.sql.DeltaCatalog "
    "--conf spark.delta.logStore.class=org.apache.spark.sql.delta.storage.S3SingleDriverLogStore "
    "--conf spark.sql.catalogImplementation=hive "
    f"--conf spark.hadoop.hive.metastore.uris={HIVE_METASTORE_URIS} "
    f"--conf spark.hadoop.fs.s3a.endpoint={MINIO_ENDPOINT} "
    f"--conf spark.hadoop.fs.s3a.access.key={MINIO_ACCESS_KEY} "
    f"--conf spark.hadoop.fs.s3a.secret.key={MINIO_SECRET_KEY} "
    "--conf spark.hadoop.fs.s3a.impl=org.apache.hadoop.fs.s3a.S3AFileSystem "
    "--conf spark.hadoop.fs.s3a.path.style.access=true "
    "--conf spark.hadoop.fs.s3a.connection.ssl.enabled=false "
    "--conf spark.hadoop.fs.s3a.aws.credentials.provider=org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider"
)

def _make_mounts():
    airflow_home = os.getenv("AIRFLOW_HOME", "/opt/airflow")
    return [
        Mount(
            source=os.path.join(airflow_home, "spark-scripts"),
            target=SPARK_SCRIPTS_DIR,
            type="bind",
            read_only=True,
        ),
        Mount(
            source="/var/run/docker.sock",
            target="/var/run/docker.sock",
            type="bind",
            read_only=False,
        ),
    ]

default_args = {
    "owner": "airflow",
    "retries": 1,
}

with DAG(
    dag_id="medallion_taxi_processing_from_defaults",
    default_args=default_args,
    start_date=pendulum.datetime(2024, 1, 1, tz="UTC"),
    catchup=False,
    schedule_interval="*/5 * * * *",
    tags=["nyc-taxi", "medallion", "from_defaults"],
    doc_md="""
    ### Quy trình xử lý dữ liệu Taxi Medallion (VN)
    Chạy các Spark job đóng gói trong Docker container, có mount Docker socket và spark-scripts.
    """,
) as dag:

    bronze_to_silver = DockerOperator(
        task_id="bronze_to_silver_vn",
        image="bitnami/spark:3.4.4",
        api_version="1.40",
        auto_remove=True,
        command=f"{SPARK_SUBMIT_CMD} {SPARK_SCRIPTS_DIR}/bronze_to_silver.py",
        docker_url="unix://var/run/docker.sock",
        network_mode="host",
        mounts=_make_mounts(),
        working_dir=SPARK_SCRIPTS_DIR,
    )

    silver_to_gold = DockerOperator(
        task_id="silver_to_gold_vn",
        image="bitnami/spark:3.4.4",
        api_version="1.40",
        auto_remove=True,
        command=f"{SPARK_SUBMIT_CMD} {SPARK_SCRIPTS_DIR}/silver_to_gold.py",
        docker_url="unix://var/run/docker.sock",
        network_mode="host",
        mounts=_make_mounts(),
        working_dir=SPARK_SCRIPTS_DIR,
    )

    register_delta_tables = DockerOperator(
        task_id="register_delta_tables_vn",
        image="bitnami/spark:3.4.4",
        api_version="1.40",
        auto_remove=True,
        command=f"{SPARK_SUBMIT_CMD} {SPARK_SCRIPTS_DIR}/register_delta_tables.py",
        docker_url="unix://var/run/docker.sock",
        network_mode="host",
        mounts=_make_mounts(),
        working_dir=SPARK_SCRIPTS_DIR,
    )

    bronze_to_silver >> silver_to_gold >> register_delta_tables
